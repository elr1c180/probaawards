import random
from django.shortcuts import render, redirect
from .forms import LoginForm, RegForm, ResetForm
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)

        # Проверка валидности данных формы:
        if form.is_valid():
            email =  form.cleaned_data['email']
            password = form.cleaned_data['password']

            if User.objects.filter(email=email, password=password):
                username = User.objects.get(email = email).username
                user = authenticate(request, username = username, password = password)
                login(request, User.objects.get(email=email))
                return redirect('/')
            else:
                messages.error(request,'Неправильный Email или пароль')
    return render(request, 'login.html', {'form': LoginForm})

def reg(request):

    if request.method == 'POST':
        form = RegForm(request.POST)

        # Проверка валидности данных формы:
        if form.is_valid():
            name = form.cleaned_data['name']
            company = form.cleaned_data['company']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            password =  form.cleaned_data['password']
            
            if Member.objects.filter(email=email):
                messages.error(request,'Пользователь с таким Email уже существует !')
            username = random.randint(1, 99999)
            user = User.objects.create(
                username = username,
                password = password,
                email = email
            )

            mem = Member.objects.create(
                user= user,
                name = name,
                company = company,
                email = email,
                phone = phone,
                password = password
            )
            
            us_auth = authenticate(username, password=password)
            login(request, user)
            
            return redirect('/')
    return render(request, 'reg.html', {'form': RegForm})

def main(request):
    if request.user.is_authenticated:
        user = Member.objects.get(user=request.user)
        return render(request, 'main.html', {'user':user})
    else:
        return redirect('login/')
    
def work(request):
    user = Member.objects.get(user=request.user)
    return render(request, 'work.html', {'user':user})

def logout_view(request):
    logout(request)
    messages.error(request,"Вы вышли из аккаунта")
    return redirect('/')

def reset(request):
    if request.method == 'POST':
        form = ResetForm(request.POST)
        if form.is_valid():
            password = form.cleaned_data['password']
        return redirect('/')
    return render(request, 'reset.html')